Radio::Radio(){
    allumer=false;
}
bool Radio::isOn() const{
    return allumer;
}
void Radio::off(bool b) {
    allumer= !b;
}
Radio::~Radio(){}
