#include"Pneu.hpp"
Pneu::Pneu(std::string ref,float diam,float press, bool isCreuve){
    reference=ref;
    diametre=diam;
    pression=press;
    creuve=isCreuve;
}
std::string Pneu::getRef() const{
    return reference;
}
void Pneu::setRef(std::string ref){
    reference=ref;
}
float Pneu::getDiametre() const{
    return diametre;
}
void Pneu::setDiametre(float diam){
    diametre=diam;
}
float Pneu::getPression() const{
    return pression;
}
void Pneu::setPression(float press){
    pression=press;
}
bool Pneu::getCreuve() const{
    return creuve;
}
void Pneu::setCreuve(bool b) const{
    creuve=b;
}
Pneu::~Pneu(){}