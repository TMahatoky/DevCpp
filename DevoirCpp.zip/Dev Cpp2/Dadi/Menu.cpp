#include"voiture.hpp"
#include"Alimentation.hpp"
#include"Television.hpp"
#include"Radio.hpp"
#include<string>
#include<vector>
#include"Menu.hpp"
#include<iostream>

Menu::Menu(Voiture myCar, Radio myRadio, Television myTv,Alimentation batterie){
    car=myCar;
    radio=myRadio;
    tv=myTv;
    battery= batterie;
    options.push_back("Quitter ce Programme");
    options.push_back("Demarrer la voiture");
    options.push_back("Demarrer la Radio à l'aide de l'alimentation de la voiture");
    options.push_back("Demarrer la Television à l'aide de l'alimentation de la voiture");
}
Voiture Menu::getCar() const{
    return car;
}
void Menu::setCar(Voiture myCar){
    car= myCar;
}
Radio Menu::getRadio() const{
    return radio;
}
void Menu::setRadio(Radio fm){
    radio=fm;
}
void Menu::getChoice(){
    std::string choix;
    bool dataRed=false;
    std::cout<<"Tapez:"<<std::endl;
    for(int i(0);i<options.size();i++){
        std::cout<<"\t\t"<<i<<" pour "<<options[i]<<std::endl;
    }
    //On va se servir du booléen dataRed pour déterminer si le choix a bien été entrer, et si le choix entrer correspond à ceux qui sont proposés
    while(!dataRed){
        std::cout<<"Entrer votre choix SVP: ";
        std::cin >> choix;
        //verifions si le choix entrée est un nombre entier compris entre 0 et le nombre d'option
        if(isNumber(choix) && 0<=stoi(choix) && stoi(choix)<options.size()){
            //La méthode stoi (string to int) permet de faire le cast d'un string en un int
            choice=stoi(choix);
            dataRed=true;
        }
    }
}
void Menu::manageChoice(bool done){
    switch(choice){
        case 0:
            //Quitter le programme
            done=true;
            std::cout<<"Merci d'avoir utiliser ce programme! Au revoir.";
            break;
        case 1:
            //Demarrer la voiture
            car.demarrer();
            tv.off(true);
            radio.off(true);
            break;
        case 2:
            //Allumer la radio
            radio.off(false);
            tv.off(true);
            car.setEnMarche(false);
            break;
        case 3:
            //Allumer la tv
            radio.off(true);
            tv.off(false);
            car.setEnMarche(false);
            break;
    }
}
Menu::~Menu(){}
bool isNumber(const string& str){
    for(char const &c : str){
        if (isdigit(c) == 0) return false;
    }
    return true;
}