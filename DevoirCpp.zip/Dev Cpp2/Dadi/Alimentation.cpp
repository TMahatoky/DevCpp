Alimentation::Alimentaion(int volt,float capacity){
    voltage=volt;
    capacite=capacity;
}
int Alimentaion::getVoltage() const{
    return voltage;
}
void Alimentation::setVoltage(int v){
    voltage=v;
}
float Alimentation::getCapacity() const{
    return capacite;
}
void Alimentation::setCapacity(float capacity){
    capacite=capacity;
}
Alimentation::~Alimentation(){}