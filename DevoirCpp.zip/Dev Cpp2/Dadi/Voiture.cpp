#include"Voiture.hpp"
#include"Pneu.hpp"
#include"Alimentation.hpp"
#include<string>
Voiture::Voiture(Alimentation battery,bool automatic, bool avance,float essence,std::string marqueVoiture,std::string imm,std::string color);
Alimentation Voiture::getAlimentation() const{
    return batterie;
}
void Voiture::setAlimentation(Alimentation battery){
    batterie=battery;
}
Pneu Voiture::getPneu() const{
    return pneus;
}
void Voiture::setPneu(Pneu wheel){
    pneus=wheel;
}
bool Voiture::isAutomatic() const{
    return automatique;
}
void Voiture::setAutomatic(bool b){
    automatique=b;
}
bool Voiture::getEnMarche() const{
    return enMarche;
}
void Voiture::setEnMarche(bool b){
    enMarche=b;
}
float Voiture::getVolumeReservoir() const{
    return volumeReservoir;
}
void Voiture::setVolumeReservoir(float essence){
    volumeReservoir=essence;
}
std::string Voiture::getMarque() const{
    return marque;
}
void Voiture::setMarque(std::string str){
    marque=str;
}
std::string Voiture::getCouleur() const{
    return couleur;
}
void Voiture::setCouleur(std::string color){
    couleur=color;
}
void Voiture::demarrer(){
    if(!pneus.creuve && volumeReservoir!=0){
        enMarche=true;
    }
    else{
        cout<<"Impossible de démarrer la voiture dû a une panne";
    }
}
Voiture::~Voiture(){} 