class Alimentation{
    private:
    int voltage;
    float capacite;
    public:
    Alimentaion(int volt,float capacity);
    int getVoltage() const;
    void setVoltage(int v);
    float getCapacity() const;
    void setCapacity(float capacity);
    ~Alimentation();
};