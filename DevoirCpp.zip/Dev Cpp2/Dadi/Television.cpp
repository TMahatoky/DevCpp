#include"Television"
Television::Television(){
    allumer=false;
}
bool Television::isOn() const{
    return allumer;
}
void Television::off(bool b) {
    allumer= !b;
}
Television::~Television(){}

}