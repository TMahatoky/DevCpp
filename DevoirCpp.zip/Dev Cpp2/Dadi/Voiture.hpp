#include<string>
#include"Pneu.hpp"
#include"Alimentation.hpp"

class Voiture{
    //Définition d'une classe Voiture, 
    private:
    Alimentation batterie;
    Pneu pneus;
    bool automatique;
    bool enMarche;
    float volumeReservoir;
    std::string marque;
    std::string immatriculation;
    std::string couleur;
    public:
    Voiture(Alimentation battery,bool automatic, bool avance,float essence,std::string marqueVoiture,std::string imm,std::string color);
    Alimentation getAlimentation() const;
    void setAlimentation(Alimentation battery);
    Pneu getPneu() const;
    void setPneu(Pneu wheel);
    bool isAutomatic() const;
    void setAutomatic(bool b);
    bool getEnMarche() const;
    void setEnMarche(bool b);
    float getVolumeReservoir() const;
    void setVolumeReservoir(float essence);
    std::string getMarque() const;
    void setMarque(std::string str);
    std::string getCouleur() const;
    void setCouleur(std::string color);
    void demarrer();
    ~Voiture(); 
};