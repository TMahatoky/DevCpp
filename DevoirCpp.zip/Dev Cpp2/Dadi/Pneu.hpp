#include<string>
class Pneu{
    private:
    std::string reference;
    float diametre;
    float pression;
    bool creuve;
    public:
    Pneu(std::string ref,float diam,float press, bool isCreuve);
    std::string getRef() const;
    void setRef(std::string ref);
    float getDiametre() const;
    void setDiametre(float diam);
    float getPression() const;
    void setPression(float press);
    bool getCreuve() const;
    void setCreuve(bool b) const;
    ~Pneu();
}