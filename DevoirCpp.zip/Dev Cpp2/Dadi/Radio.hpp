#include<vector>
#include<string>      
class Radio{
    private:
    vector<std::string> frequences;
    bool allumer;
    public:
    Radio();
    bool isOn() const;
    void off(bool b);
    Radio();
}