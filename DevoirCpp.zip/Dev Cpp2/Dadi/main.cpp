#include"Voiture.hpp"
#include"Alimentation.hpp"
#include"Television.hpp"
#include"Radio.hpp"
#include"Menu.hpp"
#include"Pneu.hpp"
#include<iostream>
using namespace std;
cout<<"Usage de la batterie"<<endl;
    bool done(false);
    Alimentation maBatterie(220,3000);
    Voiture atos(maBatterie,false,false,5,"Atos","2965TAB","rouge"); 
    Radio fm();
    Television maTv();
    Menu myMenu(atos,fm,maTv,maBatterie);
// Gère les tâches avec le menu
    while(!done){
        myMenu.getChoice();
        myMenu.manageChoice(done);
    }
    return 0;
}
