#include"voiture.hpp"
#include"Alimentation.hpp"
#include"Television.hpp"
#include"Radio.hpp"
#include<string>
#include<vector>
class Menu{
    private:
    Voiture car;
    Radio radio;
    Television tv;
    Alimentation battery;
    int choice;
    vector<std::string> options;
    public:
    Menu(Voiture myCar, Radio myRadio, Television myTv,Alimentation batterie);
    Voiture getCar() const;
    void setCar(Voiture myCar);
    Radio getRadio() const;
    void setRadio(Radio fm);
    void getChoice();
    void manageChoice(bool done);
    ~Menu();
};
bool isNumber(const string& str);