#include <iostream>
#include "Menu.h"

int main()
{
    Menu myMenu;
    bool done = false;

    while(!done)
    {
        myMenu.getChoice();
        myMenu.manageChoice(done);
    }

    return 0;
}