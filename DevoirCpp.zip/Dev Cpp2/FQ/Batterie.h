#include <string>
using namespace std;
class Batterie
{
    protected:
        string marqueBatterie;
        float niveauBatterie;
        float capaciteBatterie;
        float tension;

    public:
        Batterie();
    
        float getTension();
        float getCapaciteBatterie();
        float getNiveauBatterie();
        void setNiveauBatterie(float& pourcent);
        void infoSurLaBatterie();
        void rechargeBatterie();
   
  
    
};
