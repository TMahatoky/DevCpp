#include "Batterie.h"
#include <iostream>

Batterie::Batterie() : marqueBatterie("BOSCH") , niveauBatterie(100) , capaciteBatterie(90) , tension(12)
{
   
}
float Batterie::getTension()
{
    return tension;
}
float Batterie::getCapaciteBatterie()
{
    return capaciteBatterie;
}
float Batterie::getNiveauBatterie()
{
    return niveauBatterie;
}

void Batterie::infoSurLaBatterie()
{
    cout << "Vous avez une batterie de marque " << marqueBatterie << endl;
    cout <<  "Puissance :" << capaciteBatterie << "Ah" << endl;
    cout << "Tension : " <<    tension << "V" << endl;
    cout << "Niveau de la batterie " << niveauBatterie << endl;
}
void Batterie::setNiveauBatterie(float& pourcent)
{
    niveauBatterie -= pourcent;
    if(niveauBatterie < 0)
        niveauBatterie = 0;
    

}
void Batterie::rechargeBatterie()
{
    niveauBatterie = 100;
}
