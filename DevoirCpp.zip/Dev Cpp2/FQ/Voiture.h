//#include "Batterie.h"
class Voiture
{
    private : 
        bool voitureDemmare;
    public :
        Voiture();
        bool getVoitureDemmare();
        void setDemareVoiture(bool temp);
        bool demmareVoiture();
        


};