#include "Batterie.h"
#include <string>
class Television : public Batterie
{
    
    private : 
// consommation en Ampère d'une Television
        string marqueTelevision;
        int pouce;
        float dureUtilisation;
        float puissanceTelevision;
       

    public :
        Television();

        void setDureUtilisation(float time);
        float getDureUtilisation();
        float consommation();
        void afficheInfo();
};
