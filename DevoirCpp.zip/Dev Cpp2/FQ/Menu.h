
#include "Voiture.h"
#include "Television.h"
#include <vector>
#include <string>
# pragma once 
class Menu
{
    private :
        int choice;
        vector <string> options;
        int tailleOptoins;
        Voiture myCar;
        Television myTelevision;


    public :
        Menu();
        

        void  getChoice();
        void manageChoice(bool& done);
};