#include "Voiture.h"

Voiture::Voiture()
{
    voitureDemmare=false;
}
bool Voiture::getVoitureDemmare()
{
    return voitureDemmare;
}
 void Voiture::setDemareVoiture(bool temp)
 {
     voitureDemmare = temp;
 }