#include <iostream>
#include "Television.h"
using namespace std;

Television::Television() : Batterie(), marqueTelevision("Samsung") , pouce(32) ,  dureUtilisation(0) , puissanceTelevision(75) 
{
// on initialise la consommation a 0 car on connait pas encore la tension de la batterie

}
float Television::getDureUtilisation()
{
    return dureUtilisation;
}
 void Television::setDureUtilisation(float time)
 {
     dureUtilisation = time;
 }
 float Television::consommation()
 {
     float temp(0);
     float timeMax;
     float niveau;         
// Pour determiner la consommation de la television
     temp = puissanceTelevision / getTension();
// Pour determiner le temp maximal pour l'utilisation de la batterie
     timeMax = getCapaciteBatterie()/temp;
       if(dureUtilisation > timeMax)
     {
         dureUtilisation = timeMax;
     }
// Enfin on va calculer la diminution de la batterie en fonction de la duree d'utilisation
    niveau = dureUtilisation * 100 / timeMax;
     setNiveauBatterie(niveau);
     
     return getNiveauBatterie();

}
void Television::afficheInfo()
{
    cout << "Vous avez une Television de marque:" << marqueTelevision << endl;
    cout << "Taille de l'ecran :"<< pouce << endl;
    cout << "Puissance : " << puissanceTelevision << "Watt" << endl;
}