#include <iostream>
#include "Menu.h"
#include <vector>
using namespace std;

Menu::Menu() : choice(-1) 
{
    options.push_back("1-Pour allumer votre voiture");
    options.push_back("2-Pour allumer votre Telecision");
       options.push_back("3-Pour Voir l'etiquette de la Television");
          options.push_back("4-Pour voir l'etiquette de la Batterie");
    options.push_back("0-Pour quitter le progamme ");
    tailleOptoins = options.size();
}

void Menu::getChoice()
{
    choice = -1;
    while(choice<0 || choice > 4 )
    {
        cout << "Tapez :" << endl;
        for(int i(0); i< tailleOptoins; i++)
            cout << "\t" << options[i] << endl;
        cout << "Votre choix SVP : ";
        cin >> choice;
    }
    
 }
 void Menu::manageChoice(bool& done)
 {
     char choix;
     bool temp=false;
     float dure;
//      myBatterie.infoSurLaBatterie() ;
     switch(choice)
     {
        case 1 :   cout << "votre voiture demarre correctement"<< endl;
                     myCar.setDemareVoiture(!temp);
                     myTelevision.rechargeBatterie();
                     
                    break;
        case  2  :  
                    temp = myCar.getVoitureDemmare();
                    if(temp)
                    {
// comme la voiture est encore en marche pour pouvoir utiliser la Batterie il faudra arreter la voiture
                        while(choix != 'o')
                        {
                             cout << "Pour utiliser le batterie, On doit l'a debrancher:le voulez-vous vraiment  [o or n] : ";
                       
                         cin >> choix;
// si l'utilisateur ne souhaite pas eteindre sa voiture
                         if(choix == 'n')
                            break;
                         myCar.setDemareVoiture(!temp);
                         cout << "Votre voiture est bien etteinte" << endl;
                        }
                    }
// il est conseiller de ne pas attendre a ce que la batterie se vide pour la recharger  
                    if(myTelevision.getNiveauBatterie() < 10 )  
                         cout << "Batterie Faible, veuiller charger en le branchant a la voiture et l'a demmaree\n";
                    else
                    {
                         cout << "\nCombien d'heure souhaiterai-vous utiliser la Television : ";
                         cin >> dure;
                         myTelevision.setDureUtilisation(dure);
                         cout << "Apres " << myTelevision.getDureUtilisation()<<" h le niveau de la batterie est " << myTelevision.consommation() << endl;

                    }   
                   
                 break;
        case 3: myTelevision.afficheInfo();
                break;
        case 4: myTelevision.infoSurLaBatterie();
                break;
        case 0: 
                done = true; 
                break;
                    
     }
 }