#include <iostream>
#include "pneus.h"
#include "batterie.h"
#include "moteur.h"
#include "voiture.h"
#include "menu.h"
using namespace std;
int main(void)
{
	Voiture V;
	affiche_menu(V);
	return 0;
}