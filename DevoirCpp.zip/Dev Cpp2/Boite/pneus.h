#ifndef PNEUS_H
#define PNEUS_H
class Pneus
{
	public:
		Pneus();
		void setNbPneus(int Nb);
		void setPression(float Pr);
		void affiche_etat_pneu();
	private:
		int NbPneus;
		float Pression;
};
#endif