#include <iostream>
#include "pneus.h"
#include "batterie.h"
#include "moteur.h"
#include "voiture.h"
using namespace std;
Voiture::Voiture()
{
	P.setNbPneus(4);
	P.setPression(2.5);
	B.setAmperage(7);
	B.setVoltage(12);
	M.setPuissance(11);
	M.setCapacite(1.4);
}