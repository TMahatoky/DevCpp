#ifndef VOITURE_H
#define VOITURE_H
#include "pneus.h"
#include "batterie.h"
#include "moteur.h"
class Voiture
{
	public:
		Voiture();
		Pneus P;
		Batterie B;
		Moteur M;
};
#endif