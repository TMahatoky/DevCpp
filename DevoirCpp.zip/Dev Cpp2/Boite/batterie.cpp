#include <iostream>
#include "batterie.h"
using namespace std;
Batterie::Batterie()
{
	Amperage = 0;
	Voltage = 0;
}
void Batterie::setAmperage(float A)
{
	Amperage = A;
}
void Batterie::setVoltage(float V)
{
	Voltage = V;
}		
void Batterie::affiche_specs_batterie()
{
	cout<<"Vous avez une batterie de "<< Voltage <<"V et de " << Amperage << "A."<<endl;
}