#ifndef BATTERIE_H
#define BATTERIE_H
#include "moteur.h"
class Batterie
{
	public:
		Batterie();
		void setAmperage(float A);
		void setVoltage(float V);
		void affiche_specs_batterie();
	private:
		float Amperage;
		float Voltage;
};
#endif