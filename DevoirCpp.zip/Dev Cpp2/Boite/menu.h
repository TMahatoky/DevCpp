#ifndef MENU_H
#define MENU_H
#include "voiture.h"
void affiche_menu(Voiture Vtr);
void affiche_menu2();
#endif