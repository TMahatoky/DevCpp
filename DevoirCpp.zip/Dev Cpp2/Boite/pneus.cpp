#include <iostream>
#include "pneus.h"
using namespace std;
Pneus::Pneus()
{
	NbPneus = 0;
	Pression = 0;
}
void Pneus::setNbPneus(int Nb)
{
	NbPneus = Nb;
}
void Pneus::setPression(float Pr)
{
	Pression = Pr;
}
void Pneus::affiche_etat_pneu()
{
	cout << "Votre voiture a " << NbPneus << " roues" << endl;
	cout << "La pression de vos pneus est de " << Pression << " bar" << endl;
	if(Pression < 1.8)
		cout << "Vous devriez gonfler vos pneus!!" << endl;
	else if(Pression > 2.5)
		cout << "Vos pneus sont trop gonfles!!" << endl;
	else
		cout << "Vos pneus sont bien gonfles" << endl;
}