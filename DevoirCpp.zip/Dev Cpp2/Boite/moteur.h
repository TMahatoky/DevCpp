#ifndef MOTEUR_H
#define MOTEUR_H
class Moteur
{
	public:
		Moteur();
		void setPuissance(int P);
		void setCapacite(float C);
		void affiche_perf_moteur();
	private:
		int puissance;
		float capacite;
};
#endif