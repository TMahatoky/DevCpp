#include <iostream>
#include "moteur.h"
using namespace std;
Moteur::Moteur()
{
	puissance = 0;
	capacite = 0;
}
void Moteur::setPuissance(int P)
{
	puissance = P;
}
void Moteur::setCapacite(float C)
{
	capacite = C;
}
void Moteur::affiche_perf_moteur()
{
	cout<<"Vous avez un moteur de "<<capacite<<" dote d'une puissance de "<<puissance<<"ch."<<endl;
}