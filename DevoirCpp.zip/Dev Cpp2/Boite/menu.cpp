#include <iostream>
#include "menu.h"
#include "pneus.h"
#include "batterie.h"
#include "moteur.h"
#include "voiture.h"
using namespace std;
void affiche_menu2()
{
    cout<<"\nTapez 0 pour afficher et 1 pour modifer: ";
}
void affiche_menu(Voiture Vtr)
{
    int choice1(0);
    int choice2(0);
    bool done(false);
    while(done == false)
    {
        cout<<"Voici la liste des composants de votre voiture:"<<endl;
        cout<<"1.Pneus\n2.Batterie\n3.Moteur\n0.Quitter"<<endl;
        cout<<"Entrez votre choix: ";
        cin>>choice1;
        if(choice1 == 1)
        {
            affiche_menu2();
            cin>>choice2;
            if(choice2 == 0)
            {
                cout<<endl;
                Vtr.P.affiche_etat_pneu();
                cout<<endl;
            }
            else
            {
                int a(0);
                float b(0);
                cout<<"\nEntrez le nombre de roues de votre voiture: ";
                cin>>a;
                Vtr.P.setNbPneus(a);
                cout<<"\nFait!!\nEntrez la pression des pneus: ";
                cin>>b;
                Vtr.P.setPression(b);
                cout<<"\nFait!!"<<endl;
            }
        }
        else if(choice1 == 2)
        {
            affiche_menu2();
            cin>>choice2;
            if(choice2 == 0)
            {
                cout<<endl;
                Vtr.B.affiche_specs_batterie();
                cout<<endl;
            }
            else
            {
                float a(0);
                float b(0);
                cout<<"\nEntrez l'amperage de votre batterie: ";
                cin>>a;
                Vtr.B.setAmperage(a);
                cout<<"\nFait!!\nEntrez le voltage de votre batterie: ";
                cin>>b;
                Vtr.B.setVoltage(b);
                cout<<"\nFait!!"<<endl;
            }
        }
        else if(choice1 == 3)
        {
            affiche_menu2();
            cin>>choice2;
            if(choice2 == 0)
            {
                cout<<endl;
                Vtr.M.affiche_perf_moteur();
                cout<<endl;
            }
            else
            {
                int a(0);
                float b(0);
                cout<<"\nEntrez la puissance de votre moteur: ";
                cin>>a;
                Vtr.M.setPuissance(a);
                cout<<"\nFait!!\nEntrez la capacite de votre moteur: ";
                cin>>b;
                Vtr.M.setCapacite(b);
                cout<<"\nFait!!"<<endl;
            }
        }
        else
        {
            done = true;
        }
    }
}