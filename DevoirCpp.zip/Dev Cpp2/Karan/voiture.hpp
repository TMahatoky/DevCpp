#include "radio.hpp"
#include "batterie.hpp"
#include "essence.hpp"
#include "pneus.hpp"
class voiture{
    public:
        voiture();
        float couleur;
        pneus p;
        radio r;
        batterie b;
        string marque;
        float prix;
        essence e;
        void velocite();
};