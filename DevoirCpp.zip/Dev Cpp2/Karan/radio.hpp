class radio{
    public: 
        radio();
        float freq; 
        bool etat; 
        float vol;
        void frequence();
        void volume();
};