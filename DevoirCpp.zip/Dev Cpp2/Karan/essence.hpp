class essence{
    public:
        essence();
        float niveau; 
};
