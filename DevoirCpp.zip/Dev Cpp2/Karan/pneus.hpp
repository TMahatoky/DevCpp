class pneus{
    public:
        pneus();
        float diam;
        string type;
};
