#include <iostream>
batterie::batterie(){
    charge = 0;
    etat = false;
    brancher = false;
}
