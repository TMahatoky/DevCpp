#include <iostream>
using namespace std;
voiture::voiture(){
    marque = "";
    prix = 0; 
}
void voiture::velocite(){
    bool ongoing = false;
    bool aug = false;
    bool dim = false;
    int v = 0;
    int i = 1; 
    int vm = 0;
    while(vm == 0){
        cout << "entrer la vitesse max de la voiture:" << endl;
        cin >> vm;
    }
    while(ongoing == false){
        if(aug == false && dim == false){
            v = 0; // état initial 
        }
        else if(aug == true && dim == false){
            while(v != vm){
                v += i;
                ongoing = true;
            }
            cout << " action à prendre :" << endl;
            cin >> aug;
            cin >> dim; 
            if(aug == false && dim == true)
            {
                while(v >= 0){
                    v -= i;
                    ongoing = true;
                    if(v == 0){
                        ongoing = false;
                    }
                }
            }
        }
        else{
            cout << "action impossible";
        }
    }
}
