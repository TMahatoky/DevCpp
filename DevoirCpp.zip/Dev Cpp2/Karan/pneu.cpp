pneus::pneus(){
    diam = 0;
    type = ""; 
}
