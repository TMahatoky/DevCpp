#include <iostream>
#include "voiture.hpp"
using namespace std;
int main(){
	radio rd;
	pneus pn;
	batterie bt;
	essence es;
    voiture a;
    int i;
    cout << "entrer la fréquence de la radio voulu:" << endl;
    cin >> rd.freq;
    cout << "fréquence:" << rd.freq << ".fm" << endl;
    cout << "changeons de fréquence en guise de test:" << endl;
    rd.frequence();
    cout << "voici la fréquence actuelle: " << rd.freq << endl;
    cout << "testons le volume:" << endl;
    cout << "entrer un niveau de volume au hasard:" << endl;
    cin >> rd.vol;
    cout << "changer ce volume selon votre préférence:" << endl;
    rd.volume();
    cout << "voici le volume actuel: " << rd.vol << endl;
    cout << "voyons maintenant la charge actuelle de la batterie:" << endl;
    cout << bt.charge << endl;
    cout << "brancher la batterie en tapant 1:" << endl;
    cin >> i;
    bt.brancher = i;
    cout << ": " << bt.brancher << "\ti.e branché" << endl;
    cout << "allumer maintenant la batterie en tapant à nouveau sur 1:" << endl;
    cin >> i;
    bt.etat = i;
    cout << "etat actuelle: " << bt.etat << "\ti.e allumée" << endl;
    cout << "passant maintenant aux pneux, veuiller entrer le type de pneu voulu:" << endl;
    cin >> pn.type;
    cout << "type: " << pn.type << endl;
    cout << "entrer leurs diamètres:" << endl;
    cin >> pn.diam;
    cout << "diamètre: " << pn.diam << endl;
    cout << "le niveau d\'essence est: " << es.niveau << endl; 
    return 0;    
}
