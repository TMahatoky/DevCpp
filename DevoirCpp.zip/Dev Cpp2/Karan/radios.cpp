#include<iostream>
radio::radio(){
    freq = 0;
    etat = 0;
}
void radio::frequence(){
	int al = 0;
	while(etat == 0){
		cout << "veuiller allumer la radio en tapant 1" << endl; 
		cin >> al; 
		while(al!= 1){
			cin >> al;}
			etat = al;
		}
    int c = 1; 
    int ch;
    cout << "choisir la direction du changement: 1 ou 2 (droite ou gauche)"<< endl;
    cin >> ch;
    switch (ch)
    {
    case 1:
        freq+=c;
        break;
    case 2:
        freq-=c;
        break;
    default :
        freq+=c;
        break;
    }
}
void radio::volume(){
	int al = 0;
	while(etat == 0){
		cout << "veuiller allumer la radio en tapant 1" << endl; 
		cin >> al; 
		while(al!= 1){
			cin >> al;
			}
			etat = al;
		}
    int l = 1; 
    int cx;
    cout << "choisir la direction du changement: 1 ou 2 (augmenter ou diminuer)"<< endl;
    cin >> cx;
    switch (cx)
    {
    case 1:
        vol+=l;
        break;
    case 2:
        while(vol>0){
            vol-=l;
        }
        break;
    }
}