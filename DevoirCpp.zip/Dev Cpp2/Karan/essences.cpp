essence::essence(){
    niveau = 100;
}