class batterie{
    public:
        batterie();
        float charge;
        bool etat;
        bool brancher; 
};