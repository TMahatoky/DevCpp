#ifndef BATTERIE_HPP_INCLUDED
#define BATTERIE_HPP_INCLUDED


/*-------------------------------class Batterie----------------------------------------------*/
class Batterie{
private:
    int charge;
public:
    
    Batterie();
    void reCharger();
    void deCharger();
    void displayBat();
};

#endif