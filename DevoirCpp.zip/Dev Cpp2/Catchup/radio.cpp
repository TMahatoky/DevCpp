#include "radio.hpp"
#include "batterie.hpp"
#include <iostream>
#include <fstream>  //pour lire les données sur fichers(les chaines)

using namespace std;


/*-----------------------------définition des méthodes de la classe radio------------------------*/
Radio::Radio():etat(false), nbChaines(0){

}

//définition de la fonction initData
void Radio::initData(){
    lireDonnee();
    chaineActuelle = &m_chaines[0];
}

// implémentation de la lecture de donnée
void Radio::lireDonnee(){
    ifstream inFile;
    inFile.open("chaines.txt");
    if(inFile.is_open()){
        inFile >> nbChaines;
        for(int i=0; i<nbChaines ; i++){
            string temp;
            getline(inFile, temp);
            m_chaines.push_back(temp);
        }
    }
}

//implémentation de la fonction afficher chaine
void Radio::displayChaine() const{
    if(etat){
        cout << "vous ecoutez: "<< *chaineActuelle << endl;
        return;
    }
    cout<< "votre télé est éteind"<<endl;
}

//implémentation de la fonction changerChaine
string Radio::changerChaine(Batterie& bat){
    if(etat){
        bat.deCharger();
        if(chaineActuelle!=nullptr){
            chaineActuelle++;
            return *chaineActuelle;
        }
    }
}

//implémentation de la fonction setActive
void Radio::setActive(Batterie& bat){
    etat = true;
    bat.deCharger();
}
//implémentation de la fonction setoff
void Radio::setoff(){
    etat = false;
}