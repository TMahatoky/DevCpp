#include "voiture.hpp"
#include "radio.hpp"
#include "batterie.hpp"
#include <iostream>

Voiture::Voiture(): essence(20.0), vitesse(0){}

void Voiture::initialisation(){
    Fm.initData();
}


//définition de la fonction allumer
void Voiture::allumerVoiture(){
    isOn = true;
}
//définition de la fonction accelerer
void Voiture::accelerer(){
    int vitesseMax = 80;
    while(isOn && essence>0.0 && vitesse < 80){ 
        vitesse++;
        essence--;
    }
    
}

//définition de la fonction freiner
void Voiture::freiner(){
    while(vitesse>0){
        vitesse--;
    }
}
void Voiture::eteindreVoiture(){
    isOn = false;
}

//definition de la fonction activerRaio
void Voiture::activerRadio(){
    Fm.setActive(Bat);
}

//definition de la fonction eteindreRadio;
void Voiture::eteindreRadio(){
    Fm.setoff();
}

//définition de la fonction display etat
void Voiture::displayEtat(){
    std::cout << "vous roulez a la vitesse : "<< vitesse << std::endl;
     std::cout << "votre carburant : "<< essence << std::endl;
    Fm.displayChaine();
    std::cout << "votre batterie est  : ";
    Bat.displayBat();
}
Radio& Voiture::autorad(){
    return Fm;
}

std::string Voiture::nextChaine(){
    return Fm.changerChaine(Bat);
}




