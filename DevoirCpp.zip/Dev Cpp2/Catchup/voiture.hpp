#ifndef VOITURE_HPP_INCLUDED
#define VOITURE_HPP_INCLUDED

#include <iostream>
#include "radio.hpp"
#include "batterie.hpp"

class Voiture{
private:
    int vitesse;
    float essence;
    Radio Fm;
    bool isOn;
    Batterie Bat;
    /*Pneu roue;*/
public:
    Voiture();
    void initialisation();
    Radio& autorad();
    void displayEtat();
    void allumerVoiture();
    void eteindreVoiture();
    void accelerer(); 
    void freiner();
    void eteindreRadio();
    void activerRadio();
    std::string nextChaine();
};


#endif