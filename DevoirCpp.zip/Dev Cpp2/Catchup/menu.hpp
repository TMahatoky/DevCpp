#ifndef MENU_HPP_INCLUDED
#define MENU_HPP_INCLUDED

#include <iostream>
#include <vector>
#include "radio.hpp"
#include "voiture.hpp"
#include "batterie.hpp"

using namespace std;

class Menu{
protected:
    bool done;
    vector <string> options;
    int choice; //pour récupérer le choix
public:
    Menu();
    void getChoice();
    void manageChoice(Voiture& vehicule, Radio& Fm, Batterie& bat);
};


class Menu2 : public Menu{
public:
    void getChoice();
    void manageChoice(Voiture& vehicule, Radio& Fm, Batterie& bat);   
    Menu2();
};
#endif
