#include <iostream>
#include "menu.hpp"
#include "voiture.hpp"
#include "radio.hpp"
#include "batterie.hpp"

using namespace std;

int main(){
    Voiture vehicule;


    Voiture vehicule;
    vehicule.initialisation();

    vehicule.activerRadio();
    vehicule.nextChaine();
    vehicule.displayEtat();

    vehicule.allumerVoiture();
    vehicule.accelerer();

    vehicule.nextChaine();
    vehicule.displayEtat();
    
    return 0;
}