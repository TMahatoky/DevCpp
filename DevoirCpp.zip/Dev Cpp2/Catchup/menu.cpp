#include "menu.hpp"
#include "voiture.hpp"
#include "batterie.hpp"
#include "radio.hpp"
#include <iostream>

using namespace std;

void Menu2::getChoice(){
    options.push_back("2 pour allumer la radio");
    options.push_back("3 pour changer de chaine");
    options.push_back("4 pour afficher la chaine");
    options.push_back("5 pour accelerer");
    options.push_back("6 pour freiner");

    for(int i=0; i<options.size(); i++){
        cout << options[i] << endl;
    }

    cout << "entrer votre choix: ";
    cin >> choice;
    if (choice < 2 || choice > 6)
    {
        if(choice==0){
            return;
        }
        getChoice();
    }
}

void Menu2::manageChoice(Voiture& vehicule, Radio& Fm, Batterie& bat){
    string chaine;
    while(done){
        Menu2::getChoice();
        switch (choice){
            case 2:
                vehicule.activerRadio();
            break;

            case 3:
                Fm.displayChaine();
            break;
            case 4:
                chaine = Fm.changerChaine(bat);
            break;
            case 5:
                vehicule.accelerer();
            break;
            case 6:
                vehicule.freiner();
            break;
            case 0:
                done = false;
            break;
        }
    }
}

Menu::Menu():choice(-1), done(true){

}

void Menu::getChoice(){
    options.push_back("1 pour allumer la voiture");
    options.push_back("0 pour quitter le programme");
    for(int i=0; i<options.size(); i++){
        cout << options[i] << endl;
    }
    cout << "entrer votre choix: ";
    cin >> choice;
    if (choice < 0 || choice > 1)
    {
        getChoice();
    }
}

void Menu::manageChoice(Voiture& vehicule, Radio& Fm, Batterie& bat){
    while(done){
        getChoice();
        switch (choice){
            case 1:
                vehicule.allumerVoiture();
                /*Menu2::manageChoice(vehicule, Fm, bat);*/
            break;
    
            case 0:
                done = false;
            break;
        }
    }
}


