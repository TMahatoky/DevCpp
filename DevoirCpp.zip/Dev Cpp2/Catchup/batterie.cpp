#include "batterie.hpp"
#include <iostream>
/*----------------------------implémentation des méthodes pour la classe batterie--------------------*/
//constructeur
Batterie::Batterie(): charge(100){}
//recharger la batteries si elle est à plat
void Batterie::reCharger(){
    if(charge==0){
        charge++;
    }
}

//lorsque la battérie est en utilisation
void Batterie::deCharger(){
    if(charge>0){
        charge--;
        return;
    }
    std::cout <<"votre batterie est à plat"<<std::endl;
}

void Batterie::displayBat(){
    std::cout << charge <<std::endl;
}