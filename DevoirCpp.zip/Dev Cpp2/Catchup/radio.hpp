#ifndef RADIO_HPP_INCLUDED
#define RADIO_HPP_INCLUDED

#include "batterie.hpp"
#include <iostream> 
#include <vector>   //l'utilisation de cette structure pour les chaines

using namespace std;

class Radio{
private:
    int nbChaines;
    string* chaineActuelle;
    vector <string> m_chaines; // le nom de la chaine actuelle
    bool etat;    // variable qui vérifie si la tele est active;
    
public:
    Radio();
    void initData();
    void lireDonnee();
    void setActive(Batterie& bat);
    void setoff();
    void displayChaine() const;
    string changerChaine(Batterie& bat);
};

#endif