#include "Radio.h"



Radio::Radio()

{

	

}



Radio::~Radio()

{

	

}



bool Radio::getStatut()

{

    return this->statut;

}



void Radio::setStatut(Voiture *voiture)

{

    //this->statut = statut;

    if (voiture->getNbBatterie() > 0)

    {

        this->statut = true;

        voiture->setNbBatterie(voiture->getNbBatterie()-1);

    }

    else

    {

        this->statut = false;

    }

}