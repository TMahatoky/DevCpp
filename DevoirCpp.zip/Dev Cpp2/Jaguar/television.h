#ifndef TELEVISION_H

#define TELEVISION_H



#include "Voiture.h"



class Television

{

	private:

		bool statut;



	public:

		// constructuer

		Television();

		

		// destructeur

		~Television();

		

		// getter

		bool getStatut();



		// setter

		void setStatut(Voiture *voiture);



};



#endif