#ifndef RADIO_H

#define RADIO_H



#include "Voiture.h"



class Radio

{

	private:

		bool statut;



	public:

		// constructeur

		Radio();

		

		// destructeur

		~Radio();

		

		// getter

		bool getStatut();



		// setter

		void setStatut(Voiture *voiture);

		

};





#endif