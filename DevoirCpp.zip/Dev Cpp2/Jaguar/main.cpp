#include <iostream>

#include "Voiture.h"

#include "Television.h"

#include "Radio.h"



using namespace std;



int main()

{

	// creatio de l'objet

	Voiture *voiture = new Voiture();

	Television *tele = new Television();

	Radio *radio = new Radio();



	// initialisation des informations du voiture

	voiture->initialisation();



	cout << "\nvotre voiture est de couleur: " << voiture->getCouleur() << endl;

	

	// verifie si on a une baterie et l'utiliser pour allumer la television

	tele->setStatut(voiture);

	if(tele->getStatut())

	{

		cout << "La télevision est allumée\n";

	}

	else

	{

		cout << "Trouver une baterie\n";

	}



	cout << "Le nombre de baterie dans la voiture est maintenant: " << voiture->getNbBatterie() << endl;



	// verifie si on a une baterie et l'utiliser pour allumer la Radio

	radio->setStatut(voiture);

	if(radio->getStatut())

	{

		cout << "La télevision est allumée\n";

	}

	else

	{

		cout << "Trouver une baterie\n";

	}



	cout << "Le nombre de baterie dans la voiture est maintenant: " << voiture->getNbBatterie() << endl;



	return 0;

}