#include "Television.h"



Television::Television()

{

	

}



Television::~Television()

{

	

}



bool Television::getStatut()

{

    return this->statut;

}



void Television::setStatut(Voiture *voiture)

{

    if (voiture->getNbBatterie() > 0)

    {

        this->statut = true;

        voiture->setNbBatterie(voiture->getNbBatterie()-1);

    }

    else

    {

        this->statut = false;

    }

}