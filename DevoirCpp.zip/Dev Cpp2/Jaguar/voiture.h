#ifndef VOITURE_H

#define VOITURE_H



#include <string>



// Créaion de la classe Voiture

class Voiture

{

	private:

		std::string marque;

		int nbBatterie;

		int nbPneu;

		int nbAutoRadio;

		float vitesseMax;

		float consommation;

		std::string couleur;



	public:

		// constructeur

		Voiture();

		Voiture(std::string marque, std::string couleur,  float vitesseMax, float consommation, int nbBatterie = 1, int nbPneu = 4, int nbAutoRadio = 1);

		

		// destructeur

		~Voiture();

		

		void initialisation();



		// getter

		std::string getMarque();

		std::string getCouleur();

		float getVitesseMax();

		float getConsommation();

		int getNbBatterie();

		int getNbPneu();

		int getNbAutoRadio();

		

		//setter

		void setMarque(std::string marque);

		void setCouleur(std::string couleur);

		void setVitesseMax(float vitesseMax);

		void setConsommation(float consommation);

		void setNbBatterie(int nbBatterie);

		void setNbPneu(int nbPneu);

		void setNbAutoRadio(int nbAutoRadio);

		

};



#endif