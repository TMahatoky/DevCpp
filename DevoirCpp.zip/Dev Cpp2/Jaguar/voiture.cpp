#include "Voiture.h"

#include <iostream>



using namespace std;



// constructeur et destructeur

Voiture::Voiture()

{

	

}



/*Voiture::Voiture(std::string marque, std::string couleur,  float vitesseMax, float consommation, int nbBatterie = 1, int nbPneu = 4, int nbAutoRadio = 1) 

{

	this->marque = marque;

	this->couleur = couleur;

	this->vitesseMax = vitesseMax;

	this->consommation = consommation;

	this->nbBatterie = nbBatterie;

	this->nbPneu = nbPneu;

	this->nbAutoRadio = nbAutoRadio;

}*/



Voiture::~Voiture()

{

	

}





// Initialisation <>

void Voiture::initialisation()

{

	cout << "entrer la marque de votre voiture: ";

	cin >> this->marque;

	cout << "entrer la couleur de votre voiture: ";

	cin >> this->couleur;

	cout << "entrer la vitesse maximale de votre voiture: ";

	cin >> this->vitesseMax;

	cout << "entrer la consommation en essence de votre voiture: ";

	cin >> this->consommation;

	cout << "entrer le nombre baterie de votre voiture: ";

	cin >> this->nbBatterie;

	cout << "entrer le nombre de pneu nécessaire à votre voiture: ";

	cin >> this->nbPneu;

	cout << "entrer le nombre d'autoradio de votre voiture: ";

	cin >> this->nbAutoRadio;

}





// getter et setter

string Voiture::getMarque()

{

	return marque;

}



string Voiture::getCouleur()

{

	return couleur;	

}



float Voiture::getVitesseMax()

{

	return vitesseMax;

}



float Voiture::getConsommation()

{

	return consommation;

}



int Voiture::getNbBatterie()

{

	return nbBatterie;

}



int Voiture::getNbPneu()

{

	return nbPneu;

}



int Voiture::getNbAutoRadio()

{

	return nbAutoRadio;

}

		



void Voiture::setMarque(string marque)

{

	this->marque = marque;

}

		

void Voiture::setCouleur(string couleur)

{

	this->couleur = couleur;

}



void Voiture::setVitesseMax(float vitesseMax)

{

	this->vitesseMax = vitesseMax;

}



void Voiture::setConsommation(float consommation)

{

	this->consommation = consommation;

}



void Voiture::setNbBatterie(int nbBatterie)

{

	this->nbBatterie = nbBatterie;

}



void Voiture::setNbPneu(int nbPneu)

{

	this->nbPneu = nbPneu;

}



void Voiture::setNbAutoRadio(int nbAutoRadio)

{

	this->nbAutoRadio = nbAutoRadio;

}