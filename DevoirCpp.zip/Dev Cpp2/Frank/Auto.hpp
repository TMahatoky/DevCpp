#include <string>
#include "Batterie.hpp"
#include <vector>
//classe définissant une classe qui permet de décrire une voiture
class Auto
{
    private:
//Une voiture peut être définie par sa marque,ses nombres de pneus et sa batterie 
        std::string marque;
        int nbPneus;
        std::vector <std::string> choix;
        int choice;
//On manipule une inclusion entre classes pour pouvoir les manipuler plus souplement
        Batterie *batterie;
    public:
//constructeurs par défaut et affécté de cet arme
        Auto();
        Auto(std::string nouvelleMarque,int pneus,float couts,float duree);
        void afficherInfoAuto();
        void afficherMenu();
        void getChoice();
        void manageChoice();
//méthode qui affiche l'etat d'une voiture
        bool etatVoiture();
        ~Auto();
        std::string ConversionString();
//méthode

};
