#include "Auto.hpp"
int main()
{   
    Auto morte;
    morte.afficherMenu();
    morte.getChoice();
    morte.manageChoice();
    return 0;
}